/* ScombZ Utilities */
/* styleDialog.js */
function styleDialog(){
    'use strict';
    
    console.log("test");
}