/* ScombZ Utilities */
/* loading.js */
function onLoadingScombZ(){
    'use strict';
    console.log("loading");
    return;
}